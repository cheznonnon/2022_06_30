



#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <commdlg.h>

#include <commctrl.h>




typedef struct {

	char *class;
	HWND  hwnd;

} n_EnumWindows_classname;




BOOL CALLBACK
EnumChildProc( HWND hwnd, LPARAM lParam )
{

	// Usage
	//
	//	n_EnumWindows_classname c = { "classname", NULL };
	//	EnumChildWindows( hwnd, EnumChildProc, (LPARAM) &c );


	n_EnumWindows_classname *c = (void*) lParam;

	char name[ MAX_PATH ]; GetClassName( hwnd, name, MAX_PATH );
MessageBoxA( NULL, name, "DEBUG", 0 );

	if ( 0 == strcmp( name, c->class ) )
	{

		c->hwnd = hwnd;

		return FALSE;
	}


	return TRUE;
}

UINT_PTR CALLBACK
OFNHookProc( HWND hdlg, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{

	HWND hwnd = GetParent( hdlg );


	switch( uiMsg ) {


	case WM_INITDIALOG :

//MessageBoxA( NULL, "WM_INITDIALOG", "DEBUG", 0 );

		// Check : <dlgs.h>

		CommDlg_OpenSave_HideControl( hwnd, chx1 );	// Check : Read Only
		CommDlg_OpenSave_HideControl( hwnd, cmb1 );	// Combo : Extension
		CommDlg_OpenSave_HideControl( hwnd, stc2 );	// Label : Extension
//		CommDlg_OpenSave_HideControl( hwnd, cmb2 );	// Combo : Address
//		CommDlg_OpenSave_HideControl( hwnd, stc4 );	// Label : Address

		CommDlg_OpenSave_HideControl( hwnd, cmb13 );	// Combo : File
//		CommDlg_OpenSave_HideControl( hwnd, edt1  );	// Unknown
		CommDlg_OpenSave_HideControl( hwnd, stc3  );	// Label : File 
//		CommDlg_OpenSave_HideControl( hwnd, lst1  );	// Unknown

//		CommDlg_OpenSave_HideControl( hwnd, stc1 );	// Unknown
		CommDlg_OpenSave_HideControl( hwnd, IDOK );	// Button : OK
		CommDlg_OpenSave_HideControl( hwnd, IDCANCEL );	// Button : Cancel
//		CommDlg_OpenSave_HideControl( hwnd, pshHelp  );	// Unknown


		// Check : SysListView32 < SHELLDLL_DefView < #32770

		// Check : you cannot get HWND of SHELLDLL_DefView here

/*
{
char str[ PATH_MAX ];

// #32770
GetClassName( hdlg, str, MAX_PATH );
MessageBox( NULL, str, "DEBUG", 0 );

// #32770
GetClassName( hwnd, str, MAX_PATH );
MessageBox( NULL, str, "DEBUG", 0 );
}
*/

	break;

	case WM_NOTIFY :
	{

		NMHDR *n = (void*) lParam;


		if ( n->code == CDN_FOLDERCHANGE )
		{

			HWND h = FindWindowEx( NULL, NULL, "SHELLDLL_DefView", NULL );
			RECT r; GetWindowRect( h, &r );

			GetWindowRect( h, &r );
			ScreenToClient( hwnd, (POINT*) &r );
			int x = r.left;
			int y = r.top;

			GetClientRect( h, &r );
			int sx = r.right;
			int sy = r.bottom + 54;

			MoveWindow( h, x,y,sx,sy, TRUE );


			// Check : title
			//	Win2000 : ""
			//	WinXP   :  "FolderView"

			h = FindWindowEx( h, NULL, "SysListView32", NULL );
//if ( h != NULL ) { MessageBox( NULL, "", "DEBUG", 0 ); }
//SendMessage( h, WM_CLOSE, 0,0 );



			// Check : WinXP : set LV_VIEW_ICON

			ListView_SetView( h, 0 );

			// Check : Win9x/2000 : set LVS_ICON

			SetWindowLong( h, GWL_STYLE, GetWindowLong(h, GWL_STYLE) & ~LVS_TYPEMASK );

		}

	}
	break;


	} // switch


	return FALSE;
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	// Problem : Win95 without IE4
	//
	//	the dialog will not appear if set OFN_EXPLORER

	// Check : it will be OFF when OFN_ENABLEHOOK is ON
	//
	//	OFN_ALLOWMULTISELECT
	//	OFN_EXPLORER
	//	OFN_ENABLESIZING


    	OPENFILENAME ofn;

	char str[ PATH_MAX ]; ZeroMemory( str, PATH_MAX * sizeof( char ) );


    	ZeroMemory( &ofn, sizeof( OPENFILENAME ) );

	ofn.lStructSize       = sizeof( OPENFILENAME );
	ofn.hwndOwner         = NULL;
//	ofn.hInstance         = GetModuleHandle( NULL );
	ofn.lpstrFilter       = "";
//	ofn.lpstrCustomFilter = NULL;
//	ofn.nMaxCustFilter    = 0;
//	ofn.nFilterIndex      = 0;
	ofn.lpstrFile         = str;
	ofn.nMaxFile          = PATH_MAX;
//	ofn.lpstrFileTitle    = NULL;
//	ofn.nMaxFileTitle     = 0;
	ofn.lpstrInitialDir   = "C:\\";
	ofn.lpstrTitle        = "Nonnon";
	ofn.Flags             = OFN_EXPLORER | OFN_HIDEREADONLY;
	ofn.Flags             = ofn.Flags | OFN_ALLOWMULTISELECT | OFN_ENABLESIZING;
	ofn.Flags             = ofn.Flags | OFN_ENABLEHOOK;
//	ofn.nFileOffset       = 0;
//	ofn.nFileExtension    = 0;
//	ofn.lpstrDefExt       = NULL;
//	ofn.lCustData         = 0;
	ofn.lpfnHook          = OFNHookProc;
//	ofn.lpTemplateName    = "";




	GetOpenFileName( &ofn );

//MessageBox( NULL, str, "DEBUG", 0 );


	return 0;
}

