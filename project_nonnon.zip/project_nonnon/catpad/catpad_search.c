// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_catpad_search_txtbox( HWND hwnd )
{

	//if ( n_win_is_input( VK_SHIFT   ) ) { return; }
	//if ( n_win_is_input( VK_CONTROL ) ) { return; }


	n_posix_char *query = n_win_txtbox_line_get_new( &n_catpad_txtbox_search, 0 );


	if ( ( query[ 0 ] == n_posix_literal( '#' ) )&&( n_string_is_digit( query, 1 ) ) )
	{

		n_win_txtbox_unselect( &n_catpad_txtbox_editor );

		n_win_txtbox_select( &n_catpad_txtbox_editor, 0, n_posix_atoi( &query[ 1 ] ) - 1, 0, 1 );

		n_win_txtbox_autofocus( &n_catpad_txtbox_editor, n_false );
		n_win_txtbox_refresh( &n_catpad_txtbox_editor, N_WIN_TXTBOX_CATPAD_SEARCH );

	} else {

		// [x] : Win9x : n_win_txtbox_reset_scroll() causes redraw

		//n_win_txtbox_reset_scroll( &n_catpad_txtbox_editor );

		n_catpad_txtbox_editor.hscr.unit_pos  = 0;
		n_catpad_txtbox_editor.hscr.pixel_pos = 0;

		n_catpad_txtbox_editor.vscr.unit_pos  = 0;
		n_catpad_txtbox_editor.vscr.pixel_pos = 0;


		n_type_int x,y,sx; n_win_txtbox_select_get( &n_catpad_txtbox_editor, &x, &y, &sx, NULL );

		n_type_int caret_f = x;
		n_type_int caret_t = x + sx;
		n_posix_loop
		{

			n_string_search( n_txt_get( &n_catpad_txtbox_editor.txt, y ), query, &caret_f, &caret_t );
			if ( caret_f != caret_t ) { break; }

			caret_f = caret_t = 0;

			y++;
			if ( y >= n_catpad_txtbox_editor.txt.sy ) { y = 0; break; }
		}
//n_win_hwndprintf_literal( hwnd, "%d", y );

		n_win_txtbox_unselect( &n_catpad_txtbox_editor );

		if ( caret_f == caret_t )
		{
			n_win_txtbox_select( &n_catpad_txtbox_editor, 0, 0, 0, 1 );

			n_win_txtbox_reset_scroll( &n_catpad_txtbox_editor );

			n_win_txtbox_refresh( &n_catpad_txtbox_editor, N_WIN_TXTBOX_CATPAD_SEARCH );
		} else {
			n_win_txtbox_select_search( &n_catpad_txtbox_editor, caret_f, y, caret_t - caret_f, 1 );

			// [!] : true only
			n_win_txtbox_autofocus( &n_catpad_txtbox_editor, n_true );
			n_win_txtbox_refresh( &n_catpad_txtbox_editor, N_WIN_TXTBOX_CATPAD_SEARCH );
		}

	}


	n_string_path_free( query );


	return;
}

// internal
void
n_catpad_search_editor( HWND hwnd )
{

	// [ Mechanism ] : behavior is changed in WinXP or later
	//
	//	OLD : byte count
	//	NEW : character count

	// [x] : Win95 : not available
	//
	//	mbstring.h : _mbslen(), _mbstrlen()


	n_posix_char *query = n_win_txtbox_line_get_new( &n_catpad_txtbox_search, 0 );
	n_posix_char *text  = n_win_text_new( n_catpad_heditor );


	if ( ( query[ 0 ] == n_posix_literal( '#' ) )&&( n_string_is_digit( query, 1 ) ) )
	{

		// [!] : centering is not available

		n_win_message_send( n_catpad_heditor, EM_LINESCROLL, 0, n_posix_atoi( &query[ 1 ] ) - 1 );

	} else {

		// Restore Caret Position

		n_type_int caret_f = 0;
		n_type_int caret_t = 0;

		{

			n_type_int f, t; n_win_edit_caret_get( n_catpad_heditor, &f, &t );

#ifndef UNICODE
			if ( n_sysinfo_version_xp_or_later() )
			{
				t = n_string_cch2cb( &text[ f ], t - f );
				f = n_string_cch2cb( &text[ 0 ],     f );
				t = f + t;
			}
#endif // #ifndef UNICODE

			caret_f = f;
			caret_t = t;

		}


		n_string_search( text, query, &caret_f, &caret_t );

		if ( caret_f == caret_t ) { caret_f = caret_t = 0; }

//n_win_text_set( hwnd, text );


		// Selection

		if ( caret_f == caret_t )
		{

			n_win_edit_caret_set( n_catpad_heditor, 0, 0 );

		} else {

			n_type_int f = caret_f;
			n_type_int t = caret_t;

#ifndef UNICODE
			if ( n_sysinfo_version_xp_or_later() )
			{
				t = n_string_cch2cb( &text[ f ], t - f );
				f = n_string_cch2cb( &text[ 0 ],     f );
				t = f + t;
			}
#endif // #ifndef UNICODE

			n_win_edit_caret_set( n_catpad_heditor, f, t );

		}

		n_win_edit_caret_automove( n_catpad_heditor );

	}


	n_string_path_free( query );
	n_string_path_free( text  );


//n_win_hwndprintf_literal( hwnd, "%d - %d", caret_f, caret_t ); return;


	{ // n_catpad_search_caret_centering()

		SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };


		GetScrollInfo( n_catpad_heditor, SB_VERT, &si );

		n_type_int f = n_win_edit_line_top( n_catpad_heditor ) + ( si.nPage / 2 );
		n_type_int t = n_win_edit_line_cur( n_catpad_heditor );

//n_win_hwndprintf_literal( hwnd, "%d %d %d", f, t, si.nPage );


		// [!] : anti-flicker

		si.nPos += (int) ( t - f );

		if (
			( si.nPos >= si.nMin )
			&&
			( si.nPos <= si.nMax )
		)
		{
			n_win_message_send( n_catpad_heditor, EM_LINESCROLL, 0, t - f );
		}

	} // n_catpad_search_caret_centering()


	return;
}

void
n_catpad_search( HWND hwnd )
{

	if ( n_catpad_txtbox_onoff )
	{
		n_catpad_search_txtbox( hwnd );
	} else {
		n_catpad_search_editor( hwnd );
	}

	n_win_txtbox_line_get( &n_catpad_txtbox_search, 0, n_catpad_find );

	n_catpad_history_add( n_catpad_find );

	n_catpad_sync_send( hwnd, n_catpad_find );


	return;
}

