// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static n_win_grab_n_drag n_oc_grab_n_drag;




void
n_oc_grab_n_drag_init( void )
{

	if ( oc.view_hover != N_ORANGECAT_VIEW_HOVER_ITEM ) { return; }


	n_win_cursor_add( game.hwnd, IDC_SIZEALL );


	n_win_grab_n_drag_zero( &n_oc_grab_n_drag );
	n_win_grab_n_drag_init( &n_oc_grab_n_drag, game.hwnd );


	return;
}

void
n_oc_grab_n_drag_loop( void )
{

	int dx,dy;
	if ( n_win_grab_n_drag_loop( &n_oc_grab_n_drag, &dx, &dy ) ) { return; }

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		n_win_scrollbar_scroll_pixel( &oc.scrollbar, dx, N_WIN_SCROLLBAR_SCROLL_NONE );
	} else {
		n_win_scrollbar_scroll_pixel( &oc.scrollbar, dy, N_WIN_SCROLLBAR_SCROLL_NONE );
	}

	n_oc_event_redraw_fast();


	return;
}

void
n_oc_grab_n_drag_exit( void )
{

	n_win_grab_n_drag_exit( &n_oc_grab_n_drag );

	n_win_cursor_add( game.hwnd, IDC_ARROW );
	n_win_cursor_add(      NULL, IDC_ARROW );

	n_win_scrollbar_refresh( &oc.scrollbar );


	return;
}

void
n_oc_grab_n_drag_inertia( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_TIMER :
	{

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		int dx,dy;
		if ( n_win_grab_n_drag_inertia( &n_oc_grab_n_drag, wparam, &dx, &dy ) ) { break; }


		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			n_win_scrollbar_scroll_pixel( &oc.scrollbar, dx, N_WIN_SCROLLBAR_SCROLL_NONE );
		} else {
			n_win_scrollbar_scroll_pixel( &oc.scrollbar, dy, N_WIN_SCROLLBAR_SCROLL_NONE );
		}

		n_oc_event_redraw_fast();

	}
	break;


	} // switch


	return;
}


