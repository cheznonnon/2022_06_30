// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC
#define _H_NONNON_MAC




#include "../neutral/posix.c"




NSString*
n_mac_str2nsstring( n_posix_char *str )
{
	return [NSString stringWithUTF8String:str];
}




#endif // _H_NONNON_MAC


