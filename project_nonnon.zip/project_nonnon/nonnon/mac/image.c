// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_IMAGE
#define _H_NONNON_MAC_IMAGE




#include "../neutral/bmp/all.c"
#include "../neutral/png.c"


#include "./_mac.c"




void
n_bmp_mac( n_bmp *bmp )
{

	// [!] : format
	//
	//	ABGR
	//	upside down


	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{
		u32 color;
		n_bmp_ptr_get_fast( bmp, x,y, &color );

		color = n_bmp_argb
		(
			n_bmp_a( color ),
			n_bmp_b( color ),
			n_bmp_g( color ),
			n_bmp_r( color )
		);

		n_bmp_ptr_set_fast( bmp, x,y,  color );

		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{

			x = 0;

			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}


	n_bmp_flush_mirror( bmp, N_BMP_MIRROR_UPSIDE_DOWN );


	return;
}

NSImage*
n_mac_image_nbmp2nsimage( n_bmp *bmp )
{

	// [Needed] : a space in each line is needed (maybe)

	NSBitmapImageRep *n_rep = [
		[NSBitmapImageRep alloc]
		 initWithBitmapDataPlanes : (void*) &N_BMP_PTR( bmp )
		 pixelsWide               : N_BMP_SX( bmp )
		 pixelsHigh               : N_BMP_SY( bmp )
		 bitsPerSample            : 8
		 samplesPerPixel          : 4
		 hasAlpha                 : YES
		 isPlanar                 : NO
		 colorSpaceName           : NSCalibratedRGBColorSpace
		 bytesPerRow              : (int) N_BMP_SX( bmp ) * 4
		 bitsPerPixel             : 32
	];

//if ( n_rep == nil ) { NSLog( @"NSBitmapImageRep : nil" ); }


	NSImage *n_nsimage = [NSImage.alloc initWithSize:n_rep.size];
	[n_nsimage addRepresentation:n_rep];

//if ( n_nsimage == nil ) { NSLog( @"NSImage : nil" ); }


	return n_nsimage;
}

NSImage*
n_mac_image_path2nsimage( n_posix_char *path )
{

	n_bmp bmp; n_bmp_zero( &bmp );

	if (
		( n_png_png2bmp( path, &bmp ) )
		&&
		( n_bmp_load( &bmp, path ) )
	)
	{
		return [ [NSImage alloc] initByReferencingFile:n_mac_str2nsstring( path ) ];
	}

	n_bmp_mac( &bmp );

//NSLog( @"%d %d", N_BMP_SX( &bmp ), N_BMP_SY( &bmp ) );


	NSImage *nsimage = n_mac_image_nbmp2nsimage( &bmp );


	n_bmp_free_fast( &bmp );


	return nsimage;
}




#endif // _H_NONNON_MAC_IMAGE


