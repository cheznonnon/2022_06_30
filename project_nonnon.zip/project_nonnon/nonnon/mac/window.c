// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_WINDOW
#define _H_NONNON_MAC_WINDOW




#include "./_mac.c"




void
n_mac_window_dialog_ok( n_posix_char *text )
{

	NSAlert *alert = [[NSAlert alloc] init];

	[alert addButtonWithTitle:@"OK"];

	alert.messageText = n_mac_str2nsstring( text );

	alert.icon = [NSImage imageNamed:NSImageNameInfo];

	[alert runModal];


	return;
}

void
n_mac_window_centering( NSWindow *window )
{

	// [!] : call this at applicationWillFinishLaunching
	//
	//	it's not applicationDidFinishLaunching


	CGFloat x = ( NSWidth ( [ [window screen] frame ] ) / 2 ) - ( NSWidth ( [window frame] ) / 2 );
	CGFloat y = ( NSHeight( [ [window screen] frame ] ) / 2 ) - ( NSHeight( [window frame] ) / 2 );

	[window setFrame:NSMakeRect( x, y, NSWidth( [window frame] ), NSHeight( [window frame] ) ) display:YES ];


	return;
}

void
n_mac_window_imageview2window( NSImageView *imageview, NSWindow *window, CGFloat min_size, CGFloat max_ratio )
{

	CGFloat sx = MAX( min_size, imageview.image.size.width  );
	CGFloat sy = MAX( min_size, imageview.image.size.height );

	sx = MIN( sx, NSWidth ( [ [window screen] frame ] ) * max_ratio );
	sy = MIN( sy, NSHeight( [ [window screen] frame ] ) * max_ratio );

	NSSize size = NSMakeSize( sx,sy );
	[window setContentMinSize:size];

	NSSize minsize = [window minSize];
	NSRect rect    = NSMakeRect( 0,0,minsize.width,minsize.height );
	[window setFrame:rect display:NO];


	return;
}




#endif // _H_NONNON_MAC_WINDOW


