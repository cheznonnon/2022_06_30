// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism] : Vista or later : How to prevent GDI handle leak
//
//	[ 1 ]
//	use a retuend icon of BM_SETIMAGE to destroy
//
//	[ 2 ]
//	a : use LR_SHARED with LoadImage()
//	b : use DestroyWindow( hgui ) at WM_CLOSE explicitly


// [!] : nonnon/com/IShellLink.c
//
//	you need to include IShellLink.c top of your code
//	com.c needs to be included at first
//
//	link is needed : see nonnon/com/com.c




#ifndef _H_NONNON_WIN32_WIN_ICON
#define _H_NONNON_WIN32_WIN_ICON




//#include "../../com/IShellLink.c"


#include "../sysinfo/drive.c"

#include "../registry.c"


// [!] : don't include bmp/all.c : for reducing EXE size

#include "../../neutral/bmp.c"
#include "../../neutral/bmp/_fastcopy.c"
#include "../../neutral/bmp/filter.c"
#include "../../neutral/bmp/transform.c"

#include "../../neutral/curico.c"
#include "../../neutral/png.c"

#include "../../neutral/ini.c"


#include "./commandline.c"




#include "./_debug.c"
#include "./bitmap.c"
#include "./message.c"
#include "./stdsize.c"




#include <shellapi.h>




static n_posix_bool n_win_icon_init_replacer_check = n_posix_true;
static n_posix_bool n_win_icon_init_is_ui          = n_posix_true;




#define n_win_icon_maxcount( name ) (UINT) ExtractIcon( GetModuleHandle( NULL ), name, -1 )
//#define n_win_icon_maxcount( name ) ExtractIconEx( name, -1, NULL,NULL, 0 )

#define n_win_icon_exit( hicon ) DestroyIcon( hicon )

// internal
void
n_win_icon_bmp_replacer( n_bmp *bmp, u32 color )
{

	n_posix_bool p_trans_onoff = n_bmp_transparent_onoff( bmp, n_posix_false );

	n_bmp_flush_replacer( bmp, n_bmp_trans, color );

	n_bmp_transparent_onoff( bmp, p_trans_onoff );


	return;
}

// internal
void
n_win_icon_bmp_replacer_fast( n_bmp *bmp, u32 color )
{
//return;

	// [!] : Win2000 : UI : alpha zero will black

	if ( n_win_icon_init_replacer_check )
	{
		if ( n_posix_false == n_sysinfo_version_xp_or_later() ) { return; }
	}


	n_win_icon_bmp_replacer( bmp, color );


	return;
}

// internal
void
n_win_icon_bmp_smooth( n_bmp *bmp, n_type_real ratio )
{

	// [!] : smooth and accurate but very heavy

	n_posix_bool p_trans_onoff = n_bmp_transparent_onoff( bmp, n_posix_true );


	n_type_real smooth = 1.0 / ratio;
	if ( smooth > 1.0 )
	{
		n_posix_loop
		{//break;

			n_bmp_flush_antialias( bmp, 1.0 );

			smooth -= 1.0;
			if ( smooth < 1.0 ) { break; }
		}
	}

	if ( smooth < 1.0 ) { n_bmp_flush_antialias( bmp, smooth ); }


	n_bmp_transparent_onoff( bmp, p_trans_onoff );


	return;
}

void
n_win_icon_bmp_resize( n_bmp *bmp, n_type_gfx ico_sx, n_type_gfx ico_sy, n_type_int size, u32 color_bg, n_posix_bool stretch_onoff, n_posix_bool is_image )
{
//return;
//color_bg = n_bmp_white_invisible;

	n_type_gfx bmp_sx = N_BMP_SX( bmp );
	n_type_gfx bmp_sy = N_BMP_SY( bmp );

	if ( size <= 0 )
	{
		n_type_gfx sx, sy; n_win_stdsize_icon_large( &sx, &sy );
		size = n_posix_max_n_type_gfx( sx, sy );
	}

	if ( is_image == n_posix_false )
	{
		n_win_icon_bmp_replacer_fast( bmp, n_bmp_alpha_invisible_pixel( color_bg ) );
	}

//if ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) { n_posix_debug_literal( " %d %d %d ", size, bmp_sx, ico_sx ); }

// 64 256 52
// 24 256 52

	if (
		( is_image == n_posix_false )
		&&
		( size < bmp_sx )
		&&
		( size < ico_sx )
	)
	{

//if ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) { n_posix_debug_literal( " 1 " ); }

		n_type_real bmp_max = n_posix_max_n_type_gfx( bmp_sx, bmp_sy );
		n_type_real ratio   = size / bmp_max;
//if ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) { n_posix_debug_literal( " %f ", ratio ); }

		n_win_icon_bmp_smooth( bmp, ratio );

		n_bmp_resampler( bmp, ratio, ratio );

	} else
	if ( ( bmp_sx > ico_sx )||( bmp_sy > ico_sy ) )
	{
//if ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) { n_posix_debug_literal( " 2 " ); }

		// [Needed] : important for n_bmp_resampler()
		//
		//	for example : when resize 48px icons to 40px

		n_bmp_flush_replacer( bmp, n_bmp_black_invisible, n_bmp_white_invisible );


		//if ( 0 )
		{

			n_type_real ico_max = n_posix_max_n_type_gfx( ico_sx, ico_sy );
			n_type_real bmp_max = n_posix_max_n_type_gfx( bmp_sx, bmp_sy );
			n_type_real ratio   = bmp_max / ico_max;
//if ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) { n_posix_debug_literal( " %f ", ratio ); }

			// [!] : trunc() : some images lost bottom-right edge

			// [!] : n_bmp_usedcolors_detect() is very heavy
/*
			if ( 1024 == n_bmp_usedcolors_detect( bmp, 1024 ) )
			{
				ratio =  ceil( ratio );
			} else {
				ratio = trunc( ratio );
			}
*/
			ratio = round( ratio );

			n_bmp_smoothshrink( bmp, (int) ratio );

			bmp_sx = N_BMP_SX( bmp );
			bmp_sy = N_BMP_SY( bmp );

		}

		//if ( 0 )
		{
//n_bmp_save_literal( bmp, "0.bmp" );

			n_type_real ico_max = n_posix_max_n_type_gfx( ico_sx, ico_sy );
			n_type_real bmp_max = n_posix_max_n_type_gfx( bmp_sx, bmp_sy );
			n_type_real ratio   = ico_max / bmp_max;
//n_posix_debug_literal( " %f ", ratio );


			//n_bmp_flush_replacer( bmp, n_bmp_black_invisible, n_bmp_white_invisible );

			//n_posix_bool p_trans = n_bmp_transparent_onoff( bmp, n_posix_false );

			//n_bmp_flush_antialias( bmp, 1.0 );
			//n_bmp_resampler_main( bmp, ratio, ratio, N_BMP_BILINEAR_PIXEL_SMOOTH_SHRINK );

			//n_bmp_transparent_onoff( bmp, p_trans );


			n_bmp_resampler( bmp, ratio, ratio );


			bmp_sx = N_BMP_SX( bmp );
			bmp_sy = N_BMP_SY( bmp );

		}

	} else
	if ( ( bmp_sx < ico_sx )||( bmp_sy < ico_sy ) )
	{
//n_posix_debug_literal( " ! " );

		if ( stretch_onoff )
		{

			n_type_real ico_max = n_posix_max_n_type_gfx( ico_sx, ico_sy );
			n_type_real bmp_max = n_posix_max_n_type_gfx( bmp_sx, bmp_sy );
			n_type_real ratio   = ico_max / bmp_max;

			n_bmp_resampler( bmp, ratio, ratio );
//n_bmp_save_literal( bmp, "ret.bmp" );
			bmp_sx = N_BMP_SX( bmp );
			bmp_sy = N_BMP_SY( bmp );

		}

	}


	if ( is_image )
	{
		n_win_icon_bmp_replacer( bmp, n_bmp_rgb( 1,1,1 ) );
	}


	if ( ( N_BMP_SX( bmp ) != ico_sx )||( N_BMP_SY( bmp ) != ico_sy ) )
	{
		n_bmp_resizer( bmp, ico_sx, ico_sy, color_bg, N_BMP_RESIZER_CENTER );
	}


	return;
}

// internal
void
n_win_icon_resizer( n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 color_margin )
{

	n_bmp to; n_bmp_zero( &to ); n_bmp_1st_fast( &to, sx,sy );


	// Box

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		n_bmp_ptr_set_fast( &to, x,y, color_margin );

		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	// Centering

	{

		n_type_gfx bmpsx = N_BMP_SX( bmp );
		n_type_gfx bmpsy = N_BMP_SY( bmp );

		n_type_gfx tx = ( sx - bmpsx ) / 2;
		n_type_gfx ty = ( sy - bmpsy ) / 2;

		n_bmp_fastcopy( bmp, &to, 0,0,sx,sy, tx,ty );

	}


	n_bmp_free_fast( bmp );
	n_bmp_alias( &to, bmp );


	return;
}

void
n_win_icon_resizer_arrow( n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 color_margin )
{

	n_bmp to; n_bmp_zero( &to ); n_bmp_1st_fast( &to, sx,sy );


	// Box

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		n_bmp_ptr_set_fast( &to, x,y, color_margin );

		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	// Bottom-Left

	{

		//n_type_gfx bmpsx = N_BMP_SX( bmp );
		n_type_gfx bmpsy = N_BMP_SY( bmp );

		n_type_gfx tx = 0;
		n_type_gfx ty = ( sy - bmpsy );

		n_bmp_fastcopy( bmp, &to, 0,0,sx,sy, tx,ty );

	}


	n_bmp_free_fast( bmp );
	n_bmp_alias( &to, bmp );


	return;
}

// internal
void
n_win_icon_grayscale( n_bmp *bmp, n_bmp *msk )
{

	if ( n_bmp_error( bmp ) ) { return; }
	if ( n_bmp_error( msk ) ) { return; }


	u32 blend   = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );
	int blend_r = n_bmp_r( blend );
	int blend_g = n_bmp_g( blend );
	int blend_b = n_bmp_b( blend );


	n_type_gfx c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_gfx i = 0;
	n_posix_loop
	{

		u32 mask = N_BMP_PTR( msk )[ i ];
		if ( 0 == n_bmp_r( mask ) )
		{

			u32 color = N_BMP_PTR( bmp )[ i ];


			// [!] : alpha is reserved

			int a = n_bmp_a( color );
			int r = n_bmp_r( color );
			int g = n_bmp_g( color );
			int b = n_bmp_b( color );

			r = g = b = ( r + g + b ) / 3;


			// [Patch] : grayscale will be grayscale

			r = ( r + blend_r ) / 2;
			g = ( g + blend_g ) / 2;
			b = ( b + blend_b ) / 2;

			N_BMP_PTR( bmp )[ i ] = n_bmp_argb( a,r,g,b );

		}

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

#define n_win_icon_hicon2bmp(     h, sx,sy, b,m ) n_win_icon_hicon2bmp_internal( h, sx,sy, b,m, n_posix_false )
#define n_win_icon_hicon2bmp_1st( h, sx,sy, b,m ) n_win_icon_hicon2bmp_internal( h, sx,sy, b,m, n_posix_true  )

void
n_win_icon_hicon2bmp_internal( HICON hicon, n_type_gfx sx, n_type_gfx sy, n_bmp *b, n_bmp *m, n_posix_bool is_first )
{

	if ( hicon == NULL ) { return; }


	// [Needed] : multi-thread

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_icon_hicon2bmp_internal()" );


	ICONINFO ii; ZeroMemory( &ii, sizeof( ICONINFO ) ); GetIconInfo( hicon, &ii );


	// [x] : Win9x : GetDIBits() : fail at WM_SETTINGCHANGE sometimes

	if ( is_first )
	{
		n_bmp_1st_fast( b, sx,sy ); 
		n_bmp_1st_fast( m, sx,sy ); 
	} else {
		n_bmp_new_fast( b, sx,sy ); 
		n_bmp_new_fast( m, sx,sy ); 
	}

	n_bmp_flush( b, n_bmp_white_invisible );
	n_bmp_flush( m, n_bmp_white           );


	BITMAPINFO bi_b = { N_BMP_INFOH( b ), { { 0,0,0,0 } } };
	BITMAPINFO bi_m = { N_BMP_INFOH( m ), { { 0,0,0,0 } } };


	HDC hdc = GetDC( NULL );


	// [Mechanism]
	//
	//	ii.hbmColor may have NULL
	//	then ii.hbmMask has the both bitmap with vertical offset

	if ( ii.hbmColor != NULL )
	{
//n_bmp_flush( b, n_bmp_rgb( 0,200,255 ) );
//n_bmp_flush( m, 0 );

		GetDIBits( hdc, ii.hbmColor, 0,sy, N_BMP_PTR( b ), &bi_b, DIB_RGB_COLORS );
		GetDIBits( hdc, ii.hbmMask,  0,sy, N_BMP_PTR( m ), &bi_m, DIB_RGB_COLORS );

	} else {
//n_bmp_flush( b, n_bmp_rgb( 255,0,200 ) );
//n_bmp_flush( m, 0 );

		// [Mechanism] : this code is NT only available
		//
		//	bi.bmiHeader.biHeight *= 2;
		//
		//	GetDIBits( hdc, ii.hbmMask, sy * 0,sy * 1, N_BMP_PTR( b ), &bi_b, DIB_RGB_COLORS );
		//	GetDIBits( hdc, ii.hbmMask, sy * 1,sy * 2, N_BMP_PTR( m ), &bi_m, DIB_RGB_COLORS );

		bi_b.bmiHeader.biHeight *= 2;

		GetDIBits( hdc, ii.hbmMask, sy * 0,sy * 1, N_BMP_PTR( b ), &bi_b, DIB_RGB_COLORS );
		GetDIBits( hdc, ii.hbmMask, sy * 0,sy * 1, N_BMP_PTR( m ), &bi_m, DIB_RGB_COLORS );

	}

	// [!] : Error Code
	//
	//	[ Win95 at WM_SETTINGCHANGE ]
	//
	//	OK : ERROR_INVALID_HANDLE	dec: 6 hex: 6
	//	NG : ERROR_INVALID_PARAMETER	dec:87 hex:57

/*
if( GetLastError() )
{
n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );
n_posix_char str[ 1024 ];
n_posix_sprintf_literal( str, "%ld %lx", GetLastError(), GetLastError() );
n_txt_add( &txt, 0, str );
n_txt_save( &txt, "ret.txt" );
n_txt_free( &txt );
}
*/

	ReleaseDC( NULL, hdc );


	hmutex = n_win_mutex_exit( hmutex );


	n_win_bitmap_exit( ii.hbmColor );
	n_win_bitmap_exit( ii.hbmMask  );


	if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 )
	{
		if ( n_bmp_alpha_is_zero( b ) ) { n_bmp_alpha_reverse( b ); }
		if ( n_bmp_alpha_is_zero( m ) ) { n_bmp_alpha_reverse( m ); }
	}


	return;
}

HICON
n_win_icon_bmp2hicon( n_bmp *b, n_bmp *m )
{

	// [!] : the returned HICON needs n_win_icon_exit()


	const n_type_gfx sx = N_BMP_SX( m );
	const n_type_gfx sy = N_BMP_SY( m );


	if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 )
	{
		if ( n_bmp_alpha_is_visible( b ) ) { n_bmp_alpha_reverse( b ); }
	}


	// [Needed] : multi-thread

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_icon_bmp2hicon()" );


	HDC hdc = GetDC( NULL );


	// [!] : this code is NT only available
	//
	//	ii.hbmMask  = CreateDIBitmap( hdc, &bi.bmiHeader, CBM_INIT, N_BMP_PTR( m ), &bi, DIB_RGB_COLORS );


	BITMAPINFO bi = { N_BMP_INFOH( b ), { { 0,0,0,0 } } };


	ICONINFO ii;

	ii.hbmColor = CreateDIBitmap( hdc, &bi.bmiHeader, CBM_INIT, N_BMP_PTR( b ), &bi, DIB_RGB_COLORS );
	ii.hbmMask  = CreateBitmap( sx, sy, 1, 1, NULL );


	{ // Mask for Chicago

		HDC     hdc_compat = CreateCompatibleDC( hdc );
		HBITMAP hbmp_old   = SelectObject( hdc_compat, ii.hbmMask );


		const COLORREF white = RGB( 255,255,255 );
		const COLORREF black = RGB(   0,  0,  0 );

		u32 color;

		n_type_gfx x = 0;
		n_type_gfx y = 0;
		n_posix_loop
		{

			n_bmp_ptr_get_fast( m, x,y, &color );

			if ( color == n_bmp_white )
			{
				SetPixelV( hdc_compat, x,y, white );
			} else {
				SetPixelV( hdc_compat, x,y, black );
			}

			x++;
			if ( x >= sx )
			{

				x = 0;

				y++;
				if ( y >= sy ) { break; }
			}
		}


		SelectObject( hdc_compat, hbmp_old );
		DeleteDC( hdc_compat );

	} // Mask for Chicago


	ReleaseDC( NULL, hdc );


	hmutex = n_win_mutex_exit( hmutex );


	HICON hicon = CreateIconIndirect( &ii );

	n_win_bitmap_exit( ii.hbmColor );
	n_win_bitmap_exit( ii.hbmMask  );

	return hicon;
}

HICON
n_win_icon_grayed( HICON hicon, n_type_gfx sx, n_type_gfx sy )
{

	// [!] : the returned HICON needs n_win_icon_exit()


	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );

	n_win_icon_hicon2bmp_1st( hicon, sx, sy, &b, &m );

	n_win_icon_grayscale( &b, &m );

	HICON hicon_gray = n_win_icon_bmp2hicon( &b, &m );

	n_bmp_free_fast( &b );
	n_bmp_free_fast( &m );


	return hicon_gray;
}

#define n_win_icon_ExtractAssociatedIcon( name, index ) n_win_icon_ExtractAssociatedIcon_fast( name, index, n_posix_false )

HICON
n_win_icon_ExtractAssociatedIcon_fast( n_posix_char *icon_name, n_type_gfx icon_index, n_posix_bool is_allocated )
{

	// [x] : ExtractAssociatedIconA() on WinNT
	//
	//	crash when using a string literal

	HINSTANCE hinst = GetModuleHandle( NULL );
	WORD      word  = (WORD) icon_index;
	HICON     hicon = NULL;

	if ( is_allocated )
	{

		hicon = ExtractAssociatedIcon( hinst, icon_name, &word );

	} else {

		n_posix_char *s = n_string_carboncopy( icon_name );

		hicon = ExtractAssociatedIcon( hinst, s, &word );

		n_string_free( s );

	}


	return hicon;
}

typedef struct
{

	n_posix_char *name;
	n_type_gfx    index;
	n_type_gfx    count;
	n_posix_bool  found;

} n_win_icon_load_from_resource_struct;

BOOL CALLBACK
n_win_icon_load_from_resource_EnumResNameProc( HMODULE hModule, LPCTSTR lpszType, LPTSTR lpszName, LONG_PTR lParam )
{

	n_win_icon_load_from_resource_struct *nwilfrs = (void*) lParam;


	// [Needed] : GDB : Segmentation Fault : at n_posix_strlen()

	if ( IS_INTRESOURCE( lpszName ) )
	{
//n_posix_debug_literal( " %d ", (int) lpszName );

		//return n_posix_false;

		if ( nwilfrs->count == nwilfrs->index )
		{

			nwilfrs->name  = NULL;
			nwilfrs->index = (int) lpszName;
			nwilfrs->found = n_posix_true;

			return n_posix_false;
		}

	} else {

		if ( nwilfrs->count == nwilfrs->index )
		{
//n_posix_debug_literal( " Found : %s ", lpszName );
			nwilfrs->name  = n_string_carboncopy( lpszName );
			nwilfrs->found = n_posix_true;

			return n_posix_false;
		}

	}

	nwilfrs->count++;


	return n_posix_true;
}

#define n_win_icon_load_from_resource_1st( n, i, s, bpp, b, m, lb, ls, clr, r ) n_win_icon_load_from_resource_internal( n, i, s, bpp, b, m, lb, ls, clr, r, n_posix_true  )
#define n_win_icon_load_from_resource(     n, i, s, bpp, b, m, lb, ls, clr, r ) n_win_icon_load_from_resource_internal( n, i, s, bpp, b, m, lb, ls, clr, r, n_posix_false )

n_posix_bool
n_win_icon_load_from_resource_internal
(
	const n_posix_char *fname,
	      n_type_gfx    index,
	      n_type_gfx    size,
	      n_type_gfx    arg_bpp,
	      n_bmp        *bmp,
	      n_bmp        *msk,
	      n_type_gfx   *loaded_bpp,
	      n_type_gfx   *loaded_size,
	      u32           color_bg,
	      n_posix_bool  resize_onoff,
              n_posix_bool  is_first
)
{
//return n_posix_true;
//color_bg = n_bmp_white_invisible;

	if ( n_string_is_empty( fname ) ) { return n_posix_true; }

	if ( is_first == n_posix_false )
	{
		n_bmp_free( bmp );
		n_bmp_free( msk );
	}

	if ( bmp == NULL ) { return n_posix_true; }
	if ( msk == NULL ) { return n_posix_true; }


#pragma pack( push, 2 )

	typedef struct
	{

		BYTE   bWidth;
		BYTE   bHeight;
		BYTE   bColorCount;
		BYTE   bReserved;
		WORD   wPlanes;
		WORD   wBitCount;
		DWORD  dwBytesInRes;
		WORD   nID;

	} GRPICONDIRENTRY, *LPGRPICONDIRENTRY;

	typedef struct 
	{

		WORD            idReserved;
		WORD            idType;
		WORD            idCount;
		GRPICONDIRENTRY idEntries[ 1 ];

	} GRPICONDIR, *LPGRPICONDIR;

#pragma pack( pop )


	HMODULE hmod = LoadLibraryEx( fname, NULL, LOAD_LIBRARY_AS_DATAFILE );

	if ( hmod == NULL )
	{
//n_posix_debug_literal( " LoadLibraryEx()\n%s ", fname );
		return n_posix_true;
	}


	// [x] : some icons' order is different from ExtractIcon()

	n_posix_char str_index[ 100 ];
	if ( index < 0 )
	{
		n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, index * -1 );
		n_posix_sprintf_literal( str_index, "#%s", str );
	} else {
		n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, index +  1 );
		n_posix_sprintf_literal( str_index, "#%s", str );
	}
	HRSRC hrsrc = FindResource( hmod, str_index, RT_GROUP_ICON );

	if ( hrsrc == NULL )
	{
//if ( n_string_is_same_literal( "C:\\windows\\system32\\wscript.exe", fname ) ) { n_debug = n_posix_true; }
		n_win_icon_load_from_resource_struct nwilfrs = { NULL, index, 0, n_posix_false };

		EnumResourceNames( hmod, RT_GROUP_ICON, n_win_icon_load_from_resource_EnumResNameProc, (LONG_PTR) &nwilfrs );

		if ( nwilfrs.found )
		{
			if ( nwilfrs.name != NULL )
			{
				hrsrc = FindResource( hmod, nwilfrs.name, RT_GROUP_ICON );
				n_string_free( nwilfrs.name );
			} else {
				n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, nwilfrs.index );
				n_posix_sprintf_literal( str_index, "#%s", str );

				hrsrc = FindResource( hmod, str_index, RT_GROUP_ICON );
			}
		}

	}

	if ( hrsrc == NULL )
	{
//n_posix_debug_literal( " FindResource() " );

		FreeLibrary( hmod );

		return n_posix_true;
	}


	HGLOBAL hglbl = LoadResource( hmod, hrsrc );
	if ( hglbl == NULL )
	{
//n_posix_debug_literal( " LoadResource() : %s ", fname );

		FreeLibrary( hmod );

		return n_posix_true;
	}


	GRPICONDIR *grpicondir = LockResource( hglbl );
	if ( grpicondir == NULL )
	{
//n_posix_debug_literal( " LockResource() " );

		FreeLibrary( hmod );

		return n_posix_true;
	}


	if ( grpicondir->idCount == 0 )
	{
//n_posix_debug_literal( " if ( grpicondir->idCount == 0 ) " );

		FreeLibrary( hmod );

		return n_posix_true;
	}


	{

		n_type_gfx i = 0;
		n_posix_loop
		{break;

			if ( i >= grpicondir->idCount ) { break; }

			n_type_gfx sx  = grpicondir->idEntries[ i ].bWidth;
			n_type_gfx sy  = grpicondir->idEntries[ i ].bHeight;
			int        cb  = grpicondir->idEntries[ i ].dwBytesInRes;
			int        clr = grpicondir->idEntries[ i ].bColorCount;
			int        bit = grpicondir->idEntries[ i ].wBitCount;

			if ( sx == 0 ) { sx = 256; }
			if ( sy == 0 ) { sy = 256; }

n_posix_debug_literal
(
	" Size %dx%d : Color %d : Bit %d : %d byte ",
	sx, sy,
	clr,
	bit,
	cb
);

			i++;

		}

	}


	n_type_gfx  curico_cb    = grpicondir->idCount * sizeof( n_curico );
	n_curico   *curico       = n_memory_new_closed( curico_cb ); n_memory_zero( curico, curico_cb );
	n_type_gfx  curico_count = 0;

	n_type_gfx i = 0;
	n_posix_loop
	{

		//n_memory_copy( p, &curico[ i ], N_CURICO_SIZE_DIR );

		//n_type_gfx offset = N_CURICO_SIZE_DIR + ( i * N_CURICO_SIZE_ENTRY );
		//if ( offset < fsize )
		{
			curico[ i ].sx = grpicondir->idEntries[ i ].bWidth;
			curico[ i ].sy = grpicondir->idEntries[ i ].bHeight;

			curico_count++;
		}


		i++;
		//if ( i >= c.count ) { break; }
		if ( i >= grpicondir->idCount ) { break; }
	}


	if ( curico_count == 0 )
	{
//n_posix_debug_literal( " curico_count : %s ", fname );

		n_memory_free_closed( curico );

		FreeLibrary( hmod );

		return n_posix_true;
	}


	n_type_gfx  found_index = -1;
	n_type_gfx  found_count = -1;
	n_type_gfx *found       = n_curico_seek( curico, curico_count, size, &found_count );

	if ( found_count == 1 )
	{

		found_index = found[ 0 ];

	} else
	if ( found_count > 1 )
	{

		n_type_gfx maximum_bpp   = -1;
		n_type_gfx maximum_index = -1;

		n_type_gfx target_bpp    = -1;
		n_type_gfx target_index  = -1;

		n_type_gfx i = 0;
		n_posix_loop
		{

			n_type_gfx index = found[ i ];
			int bpp   = grpicondir->idEntries[ index ].wBitCount;

			if ( maximum_bpp < bpp )
			{
				maximum_bpp   = bpp;
				maximum_index = index;
			}

			if ( arg_bpp == bpp )
			{
				target_bpp   = bpp;
				target_index = index;
			}

			i++;
			if ( i >= found_count ) { break; }
		}

		if ( target_bpp != -1 )
		{
			found_index =  target_index;
		} else {
			found_index = maximum_index;
		}

	}

	n_memory_free_closed( found  );
	n_memory_free_closed( curico );


	if ( found_index == -1 )
	{
//n_posix_debug_literal( " Not Found : %s ", name );

		FreeLibrary( hmod );

		return n_posix_true;
	}


	int        id = grpicondir->idEntries[ found_index ].nID;
	n_type_gfx sx = grpicondir->idEntries[ found_index ].bWidth;
	n_type_gfx sy = grpicondir->idEntries[ found_index ].bHeight;
	int        cb = grpicondir->idEntries[ found_index ].dwBytesInRes;

	if ( sx == 0 ) { sx = 256; }
	if ( sy == 0 ) { sy = 256; }
//n_posix_debug_literal( " %d ", sx );


	hrsrc = FindResource( hmod, MAKEINTRESOURCE( id ), RT_ICON );
	hglbl = LoadResource( hmod, hrsrc );


	// [!] : this is not ICONIMAGE structure written on the Internet

	n_posix_bool ret = n_curico_bmp_load_onmemory( LockResource( hglbl ), cb, bmp, msk, loaded_bpp, loaded_size );

	if ( ret == n_posix_false )
	{
		if ( resize_onoff )
		{
			n_type_gfx sx = (n_type_gfx) size;//N_BMP_SX( bmp );
			n_type_gfx sy = (n_type_gfx) size;//N_BMP_SY( bmp );

			n_win_icon_bmp_resize( bmp, sx,sy, size, color_bg, n_posix_false, n_posix_false );
			n_win_icon_bmp_resize( msk, sx,sy, size, color_bg, n_posix_false, n_posix_false );
		}
	} else {
//n_posix_debug_literal( " n_curico_bmp_load_onmemory() : %s ", fname );
	}


	FreeLibrary( hmod );


	return ret;
}

n_type_gfx
n_win_icon_imageres_id_convert( n_type_gfx i, n_posix_bool *is_error )
{

	if ( i >= 200 )
	{

		if ( is_error != NULL ) { (*is_error) = n_posix_false; }

		return i;
	}


	typedef struct {

		int res;
		int ret;

	} n_table;


	// [!] : some minus value means "not found"

	n_table table[] = 
	{

		{   0,   0 },
		{   1,  -1 }, // [!] : acceptable
		{   2,   1 },
		{   3,   2 },
		{   4,   3 },
		{   5,   4 },
		{   6,   5 },
		{   7,   7 },
		{   8,   8 },
		{   9,   9 },

		{  10,  10 },
		{  11,  11 },
		{  12,  12 },
		{  13,  17 },
		{  14,  18 },
		{  15,  15 },
		{  16,  20 },
		{  17,  21 },
		{  18,  22 },
		{  19,  15 },

		{  20,  24 },
		{  21,  25 },
		{  22,  26 },
		{  23,  27 },
		{  24,  28 },
		{  25,  29 },
		{  26,  30 },
		{  27,  31 },
		{  28,  32 },
		{  29,  33 },

		{  30,  34 },
		{  31,  35 },
		{  32,  36 },
		{  33,  37 },
		{  34,  38 },
		{  35,  39 },
		{  36,  40 },
		{  37,  41 },
		{  38,  42 },
		{  39,  43 },

		{  40,  44 },
		{  41,  45 },
		{  42,  46 },
		{  43,  47 },
		{  44,  48 },
		{  45,  49 },
		{  46,  50 },
		{  47,  51 },
		{  48,  52 },
		{  49,  53 },

		{  50,  54 },
		{  51,  55 },
		{  52,  56 },
		{  53,  57 },
		{  54,  58 },
		{  55,  59 },
		{  56,  60 },
		{  57,  61 },
		{  58,  62 },
		{  59,  63 },

		{  60,  64 },
		{  61,  65 },
		{  62,  66 },
		{  63,  67 },
		{  64,  68 },
		{  65,  69 },
		{  66,  70 },
		{  67,  71 },
		{  68,  72 },
		{  69,  73 },

		{  70,  74 },
		{  71,  75 },
		{  72,  76 },
		{  73,  77 },
		{  74,  78 },
		{  75,  79 },
		{  76,  80 },
		{  77,  81 },
		{  78,  82 },
		{  79,  83 },

		{  80,  84 },
		{  81,  85 },
		{  82,  86 },
		{  83,  87 },
		{  84,  88 },
		{  85,  89 },
		{  86,  90 },
		{  87,  91 },
		{  88,  92 },
		{  89,  93 },

		{  90,  94 },
		{  91,  95 },
		{  92,  96 },
		{  93,  97 },
		{  94,  98 },
		{  95,  99 },
		{  96, 100 },
		{  97, 101 },
		{  98, 102 },
		{  99, 103 },

		{ 100, 104 },
		{ 101, 105 },
		{ 102, 106 },
		{ 103, 107 },
		{ 104, 108 },
		{ 105, 109 },
		{ 106, 110 },
		{ 107, 111 },
		{ 108, 112 },
		{ 109, 113 },

		{ 110, 114 },
		{ 111, 115 },
		{ 112, 116 },
		{ 113, 118 },
		{ 114, 119 },
		{ 115, 120 },
		{ 116, 121 },
		{ 117, 122 },
		{ 118, 123 },
		{ 119, 124 },

		{ 120, 125 },
		{ 121, 126 },
		{ 122, 127 },
		{ 123, 128 },
		{ 124, 129 },
		{ 125, 130 },
		{ 126, 131 },
		{ 127, 132 },
		{ 128, 133 },
		{ 129, 134 },

		{ 130, 135 },
		{ 131, 136 },
		{ 132, 137 },
		{ 133, 138 },
		{ 134, 139 },
		{ 135, 140 },
		{ 136, 141 },
		{ 137, 142 },
		{ 138, 143 },
		{ 139, 144 },

		{ 140, 145 },
		{ 141, 146 },
		{ 142, 147 },
		{ 143, 148 },
		{ 144, 149 },
		{ 145, 150 },
		{ 146, 151 },
		{ 147, 154 },
		{ 148, 156 },
		{ 149, 157 },

		{ 150, 158 },
		{ 151, 159 },
		{ 152, 160 },
		{ 153, 161 },
		{ 154, 162 },
		{ 155, 163 },
		{ 156, 164 },
		{ 157, 165 },
		{ 158, 166 },
		{ 159, 167 },

		{ 160, 168 },
		{ 161, 169 },
		{ 162, 170 },
		{ 163, 171 },
		{ 164, 172 },
		{ 165, 173 },
		{ 166, 174 },
		{ 167, 175 },
		{ 168, 176 },
		{ 169, 177 },

		{ 170, 178 },
		{ 171, 179 },
		{ 172, 180 },
		{ 173, 181 },
		{ 174, 182 },
		{ 175, 183 },
		{ 176, 184 },
		{ 177, 185 },
		{ 178, 188 },
		{ 179, 189 },

		{ 180, 190 },
		{ 181, 191 },
		{ 182, 192 },
		{ 183, 193 },
		{ 184, 194 },
		{ 185, 195 },
		{ 186, 196 },
		{ 187, 187 },
		{ 188,  -2 },
		{ 189,  -3 },

		{ 190,  -4 },
		{ 191,  -5 },
		{ 192,  -6 },
		{ 193,  -7 },
		{ 194,  -8 },
		{ 195,  -9 },
		{ 196, -10 },
		{ 197, -11 },
		{ 198, -12 },
		{ 199, 199 },

	};


	int ret = table[ i ].ret;


	if ( ret < -1 )
	{

		ret = 1;

		if ( is_error != NULL ) { (*is_error) = n_posix_true ; }

	} else {

		if ( is_error != NULL ) { (*is_error) = n_posix_false; }

	}


	return ret;
}

#define N_WIN_ICON_NAME_RESOLVE_SYMBOLIC_LINK ( 2 )

void
n_win_icon_name_resolve
(
	const n_posix_char *name,
	      n_posix_char *ret_name,
	      n_type_gfx   *ret_index,
	      n_type_gfx   *prv_index,
	      n_posix_bool *is_lnk,
	      n_posix_bool *is_error
)
{
//n_string_copy( name, ret_name );
//(*prv_index) = (*ret_index) = 0;
//if ( is_lnk != NULL ) { (*is_lnk) = n_posix_false; }
//return;

	if ( n_string_path_is_drivename( name ) )
	{

		u32 type = n_sysinfo_drive_type( name );

		if ( n_sysinfo_version_vista_or_later() )
		{

			n_string_copy_literal( "imageres.dll", ret_name );

			if ( type == DRIVE_REMOVABLE )
			{
				(*prv_index) = 30;
				(*ret_index) = n_win_icon_imageres_id_convert( 30, NULL );
			} else
			if ( type == DRIVE_CDROM     )
			{
				(*prv_index) = 25;
				(*ret_index) = n_win_icon_imageres_id_convert( 25, NULL );
			} else {

				n_posix_char sys_f[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
				n_posix_char sys_t[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

				n_string_copy_literal( "%SystemDrive%", sys_f );
				ExpandEnvironmentStrings( sys_f, sys_t, N_REGISTRY_ASSOCIATION_CCH_MAX );
				n_posix_strcat( sys_t, N_POSIX_SLASH );
//n_posix_debug_literal( "%s : %s", name, sys_t );

				if ( n_string_is_same( name, sys_t ) )
				{
					(*prv_index) = 31;
					(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
				} else {
					(*prv_index) = 30;
					(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
				}

			}

		} else {

			n_string_copy_literal( "shell32.dll", ret_name );

			if ( type == DRIVE_REMOVABLE )
			{
				(*ret_index) =  7;
			} else
			if ( type == DRIVE_CDROM     )
			{
				(*ret_index) = 11;
			} else {
				(*ret_index) =  8;
			}

			(*prv_index) = (*ret_index);

		}

		return;
	}


	n_type_gfx   cch = N_REGISTRY_ASSOCIATION_CCH_MAX;
	n_type_gfx   cb  = cch * sizeof( n_posix_char );
	n_posix_char exp[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( exp );
	n_posix_char ico[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( ico );
	n_posix_char def[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( def );


#ifdef _H_NONNON_WIN32_COM_ISHELLLINK

	n_posix_char *path = NULL;

	if ( n_IShellLink_is_shortcut( name ) )
	{
		path = n_string_new( N_ISHELLLINK_LNK2PATH_CCH_PATH );

		n_IShellLink_lnk2path( name, path, NULL, ret_name, ret_index );
//if ( n_posix_false != ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) ) { n_posix_debug_literal( "name : %s\npath : %s\nret : %s : %d", name, path, ret_name, *ret_index ); }

		// [x] : Win2000 : ExpandEnvironmentStrings()
		//
		//	you cannot use the same variable for in/out buffer

		n_posix_char ret[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( ret );
		ExpandEnvironmentStrings( ret_name, ret, N_REGISTRY_ASSOCIATION_CCH_MAX );

		n_string_copy( ret, ret_name );
//if ( n_posix_false != ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) ) { n_posix_debug_literal( " %s ", ret_name ); }

		if ( is_lnk != NULL ) { (*is_lnk) = n_posix_true; }

		if ( n_posix_false == n_posix_stat_is_exist( path ) )
		{
//n_posix_debug_literal( " %s ", ret_name );

			n_posix_char *dll = n_string_path_name_new( ret_name );

			if ( n_string_is_same_literal( "imageres.dll", dll ) )
			{
				(*prv_index) = (*ret_index);
				(*ret_index) = n_win_icon_imageres_id_convert( (*ret_index), is_error );
			} else {
				if ( n_sysinfo_version_vista_or_later() )
				{
					n_string_copy_literal( "imageres.dll", ret_name );
					(*prv_index) = 2;
					(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
				} else {
					n_string_copy_literal( "shell32.dll", ret_name );
					(*prv_index) = (*ret_index) = 0;
				}
			}

			n_string_path_free( dll );

		} else {

			n_posix_char *dll = n_string_path_name_new( ret_name );

			if ( n_string_is_same_literal( "imageres.dll", dll ) )
			{
				(*prv_index) = (*ret_index);
				(*ret_index) = n_win_icon_imageres_id_convert( (*ret_index), is_error );
			}

			n_string_path_free( dll );

		}

		if (
			( n_posix_false == n_string_is_empty( ret_name ) )
			&&
			( n_posix_false == n_string_is_same( path, ret_name ) )
		)
		{
			n_string_free( path );
			return;
		}
	} else {
		path = n_string_alloccopy( N_ISHELLLINK_LNK2PATH_CCH_PATH, name );

		DWORD dw = GetFileAttributes( name );
		if ( ( dw != 0xffffffff )&&( dw & FILE_ATTRIBUTE_REPARSE_POINT ) )
		{
			if ( is_lnk != NULL ) { (*is_lnk) = N_WIN_ICON_NAME_RESOLVE_SYMBOLIC_LINK; }
		}
	}

#else  // #ifdef _H_NONNON_WIN32_COM_ISHELLLINK

	n_posix_char *path = n_string_carboncopy( name );

#endif // #ifdef _H_NONNON_WIN32_COM_ISHELLLINK


//n_posix_debug_literal( "Path : %s", path );

	if ( n_posix_stat_is_file( path ) )
	{

		n_posix_char typ[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( typ );

		n_posix_char *ext = n_string_path_ext_get_new( path );
		n_registry_read( HKEY_CLASSES_ROOT, ext, N_STRING_EMPTY, typ, (DWORD) cb );
		n_string_path_free( ext );

		n_posix_sprintf_literal( ico, "%s\\DefaultIcon", typ );
		n_registry_read( HKEY_CLASSES_ROOT, ico, N_STRING_EMPTY, exp, (DWORD) cb );

		ExpandEnvironmentStrings( exp, def, N_REGISTRY_ASSOCIATION_CCH_MAX );

	} else
	if ( n_posix_stat_is_dir( path ) )
	{

		if ( n_sysinfo_version_vista_or_later() )
		{

			n_posix_char usr[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( usr );
			ExpandEnvironmentStrings( n_posix_literal( "%USERPROFILE%" ), usr, N_REGISTRY_ASSOCIATION_CCH_MAX );

			if ( n_string_is_same( name, usr ) )
			{
				(*prv_index) = 117;
				n_type_gfx index_user = n_win_icon_imageres_id_convert( (*prv_index), NULL );

				n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, index_user );
				n_posix_sprintf_literal( exp, "imageres.dll,%s", str );
			}

		}

		n_posix_char *ini_name = NULL;
		if ( n_string_is_empty( exp ) )
		{
			ini_name = n_string_path_make_new( name, n_posix_literal( "desktop.ini" ) );
		}

		if ( n_posix_stat_is_exist( ini_name ) )
		{
			n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, ini_name );


			n_posix_char *ini_section = n_posix_literal( ".ShellClassInfo" );


			// [!] : new scheme

			n_posix_char *ini_lval = n_posix_literal( "IconResource" );
			n_ini_value_str( &ini, ini_section, ini_lval, N_STRING_EMPTY, exp, cch );


			if ( n_string_is_empty( exp ) )
			{
				// [!] : old scheme

				n_posix_char str[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( str );

				n_posix_char *ini_lval_name  = n_posix_literal( "IconFile" );
				n_posix_char *ini_lval_index = n_posix_literal( "IconIndex" );
				n_ini_value_str( &ini, ini_section, ini_lval_name , N_STRING_EMPTY, exp, cch );
				n_ini_value_str( &ini, ini_section, ini_lval_index, N_STRING_EMPTY, str, cch );

				if ( n_posix_false == n_string_is_empty( exp ) )
				{
					n_posix_sprintf_literal( exp, "%s,%d", exp, n_posix_atoi( str ) );
				}
			}


			n_ini_free( &ini );
		}

		if ( n_string_is_empty( exp ) )
		{
			// [!] : shell32.dll hasn't 256px icon
			n_posix_char str[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

			n_posix_char sys[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( sys );
			ExpandEnvironmentStrings( n_posix_literal( "%SYSTEMROOT%" ), sys, N_REGISTRY_ASSOCIATION_CCH_MAX );

			n_posix_sprintf_literal( str, "%s\\system32\\imageres.dll", sys );

			if ( n_posix_stat_is_exist( str ) ) 
			{
				n_string_copy_literal( "imageres.dll,3", exp );
			} else {
				n_posix_sprintf_literal( ico, "%s", n_posix_literal( "Folder\\DefaultIcon" ) );
				n_registry_read( HKEY_CLASSES_ROOT, ico, N_STRING_EMPTY, exp, (DWORD) cb );
			}
		}
		n_string_path_free( ini_name );

		ExpandEnvironmentStrings( exp, def, N_REGISTRY_ASSOCIATION_CCH_MAX );

	}


//n_posix_debug_literal( "%s\n%s", exp, def );


	if ( n_string_is_empty( def ) )
	{
		if ( n_sysinfo_version_vista_or_later() )
		{
			n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
			(*ret_index) = -2;
		} else {
			n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "shell32.dll"  ) );
			(*ret_index) =  0;
		}
		(*prv_index) = (*ret_index);
	} else
	if ( ( n_string_is_same_literal( "%1", def ) )||( n_string_is_same_literal( "\"%1\"", def ) ) )
	{
		n_posix_sprintf_literal( ret_name, "%s", path );
//n_posix_debug_literal( "%s", ret_name );

		if ( n_string_path_ext_is_same_literal( ".exe\0\0", ret_name ) )
		{
			if ( 0 == n_win_icon_maxcount( ret_name ) )
			{
				if ( n_sysinfo_version_vista_or_later() )
				{
					n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
					(*prv_index) = 11;
					(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
				} else {
					n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "shell32.dll"  ) );
					(*prv_index) = 2;
					(*ret_index) = (*prv_index);
				}
			}
		} else
		if ( n_string_path_ext_is_same_literal( ".bat\0\0", ret_name ) )
		{
			if ( n_sysinfo_version_vista_or_later() )
			{
				n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
				(*prv_index) = 63;
				(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
			} else {
				n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "shell32.dll"  ) );
				int new_index;
				if ( n_sysinfo_version_95() )
				{
					new_index = 60;
				} else
				if ( n_sysinfo_version_98() )
				{
					new_index = 65;
				} else {
					new_index = 71;
				}
				(*prv_index) = new_index;
				(*ret_index) = (*prv_index);
			}
		} else {
			if ( 0 == n_win_icon_maxcount( ret_name ) )
			{
				if ( n_sysinfo_version_vista_or_later() )
				{
					n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
					(*prv_index) = 2;
					(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
				} else {
					n_posix_sprintf_literal( ret_name, "%s", n_posix_literal(  "shell32.dll" ) );
					(*prv_index) = 0;
					(*ret_index) = (*prv_index);
				}
			}
		}
	} else {

		n_posix_char *str_index = n_string_new( n_posix_strlen( def ) );

		n_string_parameter( def, N_STRING_COMMA, N_STRING_EMPTY, 0, ret_name  );
		n_string_parameter( def, N_STRING_COMMA, N_STRING_EMPTY, 1, str_index );

		(*prv_index) = (*ret_index) = n_posix_atoi( str_index );

		n_string_free( str_index );

//n_posix_debug_literal( "Ret : %s : %d", ret_name, (*ret_index) );
	}


	if ( n_string_is_empty( ret_name ) )
	{
		if ( n_sysinfo_version_vista_or_later() )
		{
			n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
			(*prv_index) = 2;
			(*ret_index) = n_win_icon_imageres_id_convert( (*prv_index), NULL );
		} else {
			n_posix_sprintf_literal( ret_name, "%s", n_posix_literal(  "shell32.dll" ) );
			(*prv_index) = 0;
			(*ret_index) = (*prv_index);
		}
	}


	n_string_free( path );


	return;
}

// internal
void
n_win_icon_linkarrow( n_bmp *b, n_bmp *m, n_type_gfx size )
{

	// [!] : is_first only

	u32 bg = n_bmp_white_invisible;

	if ( n_sysinfo_version_vista_or_later() )
	{
		n_type_gfx id = n_win_icon_imageres_id_convert( 154, NULL );
		n_win_icon_load_from_resource( n_posix_literal( "imageres.dll" ), id, size, 8, b, m, NULL, NULL, bg, n_posix_false );
	} else {
		n_win_icon_load_from_resource( n_posix_literal(  "shell32.dll" ), 29, size, 8, b, m, NULL, NULL, bg, n_posix_false );
	}


	return;
}

// internal
void
n_win_icon_linkarrow_draw( n_bmp *b, n_bmp *m, n_type_gfx size, n_posix_bool is_lnk )
{

	if ( is_lnk == n_posix_false ) { return; }


	n_bmp b_arrow; n_bmp_zero( &b_arrow );
	n_bmp m_arrow; n_bmp_zero( &m_arrow );


	n_type_gfx ico_sx, ico_sy; n_win_stdsize_icon_large( &ico_sx, &ico_sy );

	n_win_icon_linkarrow( &b_arrow, &m_arrow, ico_sx );

	if ( ico_sx != size )
	{
		n_type_gfx s = (n_type_gfx) size;
		n_win_icon_resizer_arrow( &b_arrow, s, s, n_bmp_black );
		n_win_icon_resizer_arrow( &m_arrow, s, s, n_bmp_black );
	}

//n_bmp_save_literal( &b_arrow, "./b_arrow.bmp" );

	if ( is_lnk == N_WIN_ICON_NAME_RESOLVE_SYMBOLIC_LINK )
	{

		n_type_gfx c = N_BMP_SX( &b_arrow ) * N_BMP_SY( &b_arrow );
		n_type_gfx i = 0;
		n_posix_loop
		{

			u32 color = N_BMP_PTR( &b_arrow )[ i ];
			if ( ( color != n_bmp_black )&&( color != n_bmp_black_invisible ) )
			{
				N_BMP_PTR( &b_arrow )[ i ] = n_bmp_hue_wheel_tweak_pixel( color, 64 );
			}

			i++;
			if ( i >= c ) { break; }
		}

	}

	{

		n_type_gfx c = N_BMP_SX( b ) * N_BMP_SY( b );
		n_type_gfx i = 0;
		n_posix_loop
		{

			u32 color = N_BMP_PTR( b )[ i ];
			if ( ( color == n_bmp_black )||( color == n_bmp_black_invisible ) )
			{
				N_BMP_PTR( b )[ i ] = n_bmp_white_invisible;
			}

			i++;
			if ( i >= c ) { break; }
		}

	}

	{

		//n_bmp_flush_blendcopy( &b_arrow, b, 0.125 );

		n_type_gfx c = N_BMP_SX( &b_arrow ) * N_BMP_SY( &b_arrow );
		n_type_gfx i = 0;
		n_posix_loop
		{//break;

			u32 color = N_BMP_PTR( &b_arrow )[ i ];
			if ( ( color != n_bmp_black )&&( color != n_bmp_black_invisible ) )
			{
				N_BMP_PTR( b )[ i ] = n_bmp_blend_pixel( color, N_BMP_PTR( b )[ i ], 0.125 );
			}

			i++;
			if ( i >= c ) { break; }
		}

	}

	if ( n_posix_false == n_bmp_error( m ) )
	{

		n_type_gfx c = N_BMP_SX( &m_arrow ) * N_BMP_SY( &m_arrow );
		n_type_gfx i = 0;
		n_posix_loop
		{

			u32 color = N_BMP_PTR( &m_arrow )[ i ];
			if ( color == n_bmp_black )
			{
				N_BMP_PTR( m )[ i ] = color;
			}

			i++;
			if ( i >= c ) { break; }
		}

	}

//n_bmp_save_literal( &b_arrow, "./b_arrow.bmp" );
//n_bmp_save_literal( &m_arrow, "./m_arrow.bmp" );

	n_bmp_free_fast( &b_arrow );
	n_bmp_free_fast( &m_arrow );

//n_bmp_save_literal( b, "./b.bmp" );
//n_bmp_save_literal( m, "./m.bmp" );


	return;
}

#define N_WIN_ICON_INIT_OPTION_DEFAULT      ( 0 << 0 )
#define N_WIN_ICON_INIT_OPTION_RESOURCE     ( 1 << 0 )
#define N_WIN_ICON_INIT_OPTION_NAME_RESOLVE ( 1 << 1 )
#define N_WIN_ICON_INIT_OPTION_LINK_RESOLVE ( 1 << 2 )

#define n_win_icon_init_large( s, i, opt ) n_win_icon_init_internal( s, i, 32, -1, NULL,NULL, NULL,NULL, n_bmp_white_invisible, n_posix_true , 0, n_posix_true, NULL, NULL, NULL, opt )
#define n_win_icon_init_small( s, i, opt ) n_win_icon_init_internal( s, i, 32, -1, NULL,NULL, NULL,NULL, n_bmp_white_invisible, n_posix_false, 0, n_posix_true, NULL, NULL, NULL, opt )

#define n_win_icon_init(         s, i, opt ) n_win_icon_init_large( s, i, opt )
#define n_win_icon_init_literal( s, i, opt ) n_win_icon_init( n_posix_literal( s ), i, opt )

typedef void (*n_win_icon_init_callback_type)( n_bmp *b, n_bmp *m );

static n_win_icon_init_callback_type n_win_icon_init_callback = NULL;

// internal
HICON
n_win_icon_init_internal
(
	n_posix_char *icon_name,
	n_type_gfx    icon_index,
	n_type_gfx    icon_bpp,
	n_type_gfx    icon_size,
	n_bmp        *bmp,
	n_bmp        *msk,
	n_type_gfx   *loaded_bpp,
	n_type_gfx   *loaded_size,
	u32           color_bg,
	n_posix_bool  is_large,
	n_type_gfx    stop_pixel,
	n_posix_bool  resize_onoff,
	n_posix_bool *is_lnk,
	n_posix_bool *resize_needed,
	n_posix_bool *is_error,
	int           option
)
{

	// [!] : the returned HICON needs n_win_icon_exit()


	if ( is_error != NULL ) { (*is_error) = n_posix_true; }
//return NULL;


	n_type_gfx fsx,fsy, tsx,tsy;

	n_type_gfx ui_ratio = 0;

	if ( is_large )
	{
		fsx = 32;
		fsy = 32;
		if ( n_win_icon_init_is_ui )
		{
			tsx = tsy = 32;

			n_type_gfx tmp; n_win_stdsize_icon_large( &tmp, NULL );
			ui_ratio = tmp / tsx;
		} else {
			n_win_stdsize_icon_large( &tsx, &tsy );
		}
	} else {
		fsx = 16;
		fsy = 16;
		n_win_stdsize_icon_small( &tsx, &tsy );
	}

	if ( icon_size <= 0 )
	{

		int step = 8;
		n_posix_loop
		{//break;

			if ( fsx >= ( tsx - stop_pixel ) ) { break; }

			fsx += step;
			fsy += step;

		}

		icon_size = fsx;

	} else {

		fsx = fsy = tsx = tsy = (n_type_gfx) icon_size;

	}
//n_posix_debug_literal( "%d:%d", fsx,fsy );


	HICON hicon = NULL;

	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );


	// [!] : for performance

	n_posix_bool fallback = n_posix_true;

	n_type_gfx   resolve_p_id = icon_index;
	n_posix_char resolve_name[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( resolve_name );

	if ( option & N_WIN_ICON_INIT_OPTION_RESOURCE )
	{

		if ( option & N_WIN_ICON_INIT_OPTION_NAME_RESOLVE )
		{

			n_type_gfx   resolve_index = icon_index;
			n_posix_bool resolve_error = n_posix_false;

			if ( icon_name == NULL )
			{
				n_posix_char *name = n_win_exepath_new();
				n_win_icon_name_resolve(      name, resolve_name, &resolve_index, &resolve_p_id, is_lnk, &resolve_error );
				n_string_path_free( name );
			} else {
				n_win_icon_name_resolve( icon_name, resolve_name, &resolve_index, &resolve_p_id, is_lnk, &resolve_error );
			}
//if ( n_posix_false != ( 0x8000 & GetAsyncKeyState( VK_CONTROL ) ) ) { n_posix_debug_literal( "%s\n%s : %d", icon_name, resolve_name, resolve_index ); }

			if ( resolve_error == n_posix_false )
			{
				fallback = n_win_icon_load_from_resource_1st( resolve_name, resolve_index, icon_size, icon_bpp, &b, &m, loaded_bpp, loaded_size, color_bg, resize_onoff );
				if ( fallback == n_posix_false ) { resize_onoff = n_posix_false; }
			}

			if ( ( bmp != NULL )&&( fallback ) )
			{
//n_posix_debug_literal( "%s\n%s", icon_name, resolve_name );
				fallback = n_curico_extract( resolve_name, &b, icon_size, icon_bpp, loaded_bpp, loaded_size );

				if ( fallback == n_posix_false )
				{
					//n_bmp_free( &b );
					n_bmp_free( &m );

					n_bmp_free_fast( bmp );
					n_bmp_free_fast( msk );

					n_bmp_alias( &b, bmp );
					n_bmp_alias( &m, msk );

					if ( is_error != NULL ) { (*is_error) = fallback; }

					return NULL;
				} else {
//n_posix_debug_literal( "Error\n%s\n%s", icon_name, resolve_name );
				}
			}

//if ( n_posix_stat_is_dir( icon_name ) ) { n_bmp_save_literal( &b, "1.bmp" ); }

		} else {

			if ( icon_name == NULL )
			{
				n_posix_char *name = n_win_exepath_new();
				fallback = n_win_icon_load_from_resource_1st(      name, icon_index, icon_size, icon_bpp, &b, &m, loaded_bpp, loaded_size, color_bg, resize_onoff );
				n_string_path_free( name );
			} else {
				fallback = n_win_icon_load_from_resource_1st( icon_name, icon_index, icon_size, icon_bpp, &b, &m, loaded_bpp, loaded_size, color_bg, resize_onoff );
			}

			if ( fallback == n_posix_false ) { resize_onoff = n_posix_false; }

//if ( n_posix_stat_is_dir( icon_name ) ) { n_bmp_save_literal( &b, "2.bmp" ); }
		}

	}


	if ( ( bmp != NULL )&&( fallback ) )
	{

		if ( n_string_is_empty( resolve_name ) )
		{
			fallback = n_curico_extract(    icon_name, &b, icon_size, icon_bpp, loaded_bpp, loaded_size );
		} else {
			fallback = n_curico_extract( resolve_name, &b, icon_size, icon_bpp, loaded_bpp, loaded_size );
		}
//n_bmp_new( &b, fsx, fsy );
//n_bmp_new( &m, N_BMP_SX( &b ), N_BMP_SY( &b ) );

		if ( fallback == n_posix_false )
		{
			//n_bmp_free( &b );
			n_bmp_free( &m );

			n_bmp_free_fast( bmp );
			n_bmp_free_fast( msk );

			n_bmp_alias( &b, bmp );
			n_bmp_alias( &m, msk );

			if ( is_error != NULL ) { (*is_error) = fallback; }

			return NULL;
		}
	}


//fallback = n_posix_false;
	if ( fallback )
	{

		// [!] : Vista or later : LR_SHARED + DestroyWindow() only prevents GDI handle leak

		n_posix_char *name = NULL;

		if ( icon_name == NULL )
		{
			name = n_win_exepath_new();
		}

		if ( hicon == NULL )
		{
			const HINSTANCE hinst = GetModuleHandle( NULL );
			UINT lr = LR_DEFAULTCOLOR | LR_SHARED;

			if ( icon_name == NULL )
			{
				hicon = LoadImage( hinst,         name, IMAGE_ICON, fsx,fsy, lr );
			} else
			if ( n_posix_false == n_string_is_empty( resolve_name ) )
			{
				hicon = LoadImage( hinst, resolve_name, IMAGE_ICON, fsx,fsy, lr );
			} else {
				hicon = LoadImage( hinst,    icon_name, IMAGE_ICON, fsx,fsy, lr );
			}

		}
		if ( hicon == NULL )
		{

			const HINSTANCE hinst = GetModuleHandle( NULL );

			if ( icon_name == NULL )
			{
				hicon = ExtractIcon( hinst,         name, (UINT) resolve_p_id );
			} else 
			if ( n_posix_false == n_string_is_empty( resolve_name ) )
			{
				hicon = ExtractIcon( hinst, resolve_name, (UINT) resolve_p_id );
			} else {
				hicon = ExtractIcon( hinst,    icon_name, (UINT) resolve_p_id );
			}

		}
		if ( hicon == NULL )
		{

			if ( icon_name == NULL )
			{
				hicon = n_win_icon_ExtractAssociatedIcon_fast(         name, resolve_p_id, n_posix_true  );
			} else
			if ( n_posix_false == n_string_is_empty( resolve_name ) )
			{
				// [x] : crash : "n_posix_true" only
				hicon = n_win_icon_ExtractAssociatedIcon_fast( resolve_name, resolve_p_id, n_posix_true  );
			} else {
				hicon = n_win_icon_ExtractAssociatedIcon_fast(    icon_name, resolve_p_id, n_posix_false );
			}

		}

		if ( icon_name == NULL )
		{
			n_string_path_free( name );
		}


		if ( is_error != NULL ) { (*is_error) = ( hicon == NULL ); }


		if ( hicon == NULL ) { return NULL; }


		if ( resize_needed != NULL ) { (*resize_needed) = n_posix_false; }


		// [!] : for performance

		if ( bmp == NULL )
		{
			if ( ( fsx == tsx )&&( fsy == tsy ) )
			{
				return hicon;
			}
		}

//if ( ii.hbmColor == NULL ) { n_win_icon_exit( hicon ); return NULL; }
//if ( ii.hbmMask  == NULL ) { n_win_icon_exit( hicon ); return NULL; }


		n_type_gfx icon_sx, icon_sy; n_win_stdsize_icon( &icon_sx, &icon_sy, is_large );

		n_win_icon_hicon2bmp_1st( hicon, icon_sx,icon_sy, &b, &m );

		n_curico_mask_restore( &b, &m );
//n_posix_debug_literal( "%s : %d %d %d", icon_name, fsx, tsx, icon_size );

//n_posix_char *_name = n_string_path_name_new( icon_name );
//n_posix_char str[ 1024 ]; n_posix_sprintf_literal( str, "./_empty/%s.bmp", _name );
//n_bmp_save( &b, str );
//n_string_path_free( _name );
	} else {

		if ( is_error != NULL ) { (*is_error) = fallback; }

	}


	if ( n_win_icon_init_is_ui )
	{
		n_win_icon_bmp_replacer_fast( &b, color_bg );

		n_bmp_scaler_big( &b, ui_ratio );
		n_bmp_scaler_big( &m, ui_ratio );

		n_win_stdsize_icon_large( &tsx, &tsy );
		n_win_icon_resizer( &b, tsx,tsy, color_bg    );
		n_win_icon_resizer( &m, tsx,tsy, n_bmp_white );
	} else
	if ( resize_onoff )
	{
		n_win_icon_bmp_replacer_fast( &b, color_bg );

		int ratio = tsx / fsx;
		n_bmp_scaler_big( &b, ratio );
		n_bmp_scaler_big( &m, ratio );

		n_win_icon_resizer( &b, tsx,tsy, color_bg    );
		n_win_icon_resizer( &m, tsx,tsy, n_bmp_white );
	}


	if (
		( option == N_WIN_ICON_INIT_OPTION_LINK_RESOLVE )
		&&
		( fallback == n_posix_false )
	)
	{
		n_win_icon_linkarrow_draw( &b, &m, tsx, (*is_lnk) );
	}


//n_bmp_save_literal( &b, "./b.bmp" );
//n_bmp_save_literal( &m, "./m.bmp" );

//n_bmp_flush( &b, 0xffffffff );
//n_bmp_flush( &m, 0xffffffff );

// 16x16 : 4byte == 16 pixel : bottom half will be applied
//n_bmp_box( &m, 0,0, 2,1, 0 );

//if ( icon_size != -1 )
//{
//n_bmp_save_literal( &b, "./b.bmp" );
//n_bmp_save_literal( &m, "./m.bmp" );
//}
	n_win_icon_exit( hicon );


	if ( n_win_icon_init_callback != NULL )
	{
		n_win_icon_init_callback( &b, &m );
	}


	if ( bmp != NULL )
	{

		hicon = NULL;

		n_bmp_free_fast( bmp );
		n_bmp_free_fast( msk );

		n_bmp_alias( &b, bmp );
		n_bmp_alias( &m, msk );

	} else {

		hicon = n_win_icon_bmp2hicon( &b, &m );

		n_bmp_free_fast( &b );
		n_bmp_free_fast( &m );

	}


//if ( fallback ) { n_posix_debug_literal( " %s ", icon_name ); }
	return hicon;
}


//#pragma GCC pop_options




HICON
n_win_icon_get( HWND hgui )
{

	// [!] : GDI handle leak : don't use a returned icon as the last icon to destroy

	if ( n_win_class_is_same_literal( hgui, "Static" ) )
	{
		return (HICON) n_win_message_send( hgui, STM_GETIMAGE, IMAGE_ICON, 0 );
	} else
	if ( n_win_class_is_same_literal( hgui, "Button" ) )
	{
		return (HICON) n_win_message_send( hgui, BM_GETIMAGE,  IMAGE_ICON, 0 );
	}


	return NULL;
}

#define n_win_icon_del( h ) n_win_icon_set( h, NULL )

#define n_win_icon_add(         h, s, i ) n_win_icon_set( h, n_win_icon_init(         s, i, N_WIN_ICON_INIT_OPTION_DEFAULT ) )
#define n_win_icon_add_literal( h, s, i ) n_win_icon_set( h, n_win_icon_init_literal( s, i, N_WIN_ICON_INIT_OPTION_DEFAULT ) )

void
n_win_icon_set( HWND hgui, HICON hicon )
{
//n_win_icon_exit( hicon ); return;

	if ( n_win_class_is_same_literal( hgui, "Static" ) )
	{
		n_win_icon_exit( (HICON) n_win_message_send( hgui, STM_SETIMAGE, IMAGE_ICON, hicon ) );
	} else
	if ( n_win_class_is_same_literal( hgui, "Button" ) )
	{
		n_win_icon_exit( (HICON) n_win_message_send( hgui, BM_SETIMAGE,  IMAGE_ICON, hicon ) );
	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_ICON

