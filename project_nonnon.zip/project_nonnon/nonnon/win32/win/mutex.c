// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_MUTEX
#define _H_NONNON_WIN32_WIN_MUTEX




// [!] : Partial File

//#include <windows.h>




// [Needed] : keep independency

#define n_win_mutex_false        FALSE

#ifdef UNICODE

#define	n_win_mutex_literal( q ) L##q
#define n_win_mutex_char         wchar_t

#else // #ifdef UNICODE

#define	n_win_mutex_literal( q ) q
#define n_win_mutex_char         char

#endif // #ifdef UNICODE




HANDLE
n_win_mutex_exit( HANDLE hmutex )
{

	ReleaseMutex( hmutex );
	CloseHandle ( hmutex );

	hmutex = NULL;


	return hmutex;
}

#define n_win_mutex_loop n_thread_wait

#define n_win_mutex_init_literal( h, n ) n_win_mutex_init( h, n_win_mutex_literal( n ) )

HANDLE
n_win_mutex_init( HANDLE hmutex, const n_win_mutex_char *name )
{

	if ( name      == NULL ) { return hmutex; }
	if ( name[ 0 ] == '\0' ) { return hmutex; }


	HANDLE h = CreateMutex( NULL, n_win_mutex_false, name );

	if ( ERROR_ALREADY_EXISTS == GetLastError() )
	{
		n_win_mutex_exit( h );
		h = hmutex;
	} else {
		n_win_mutex_exit( hmutex );
	}


	return h;
}

#define n_win_mutex_init_and_wait_literal( h, n ) n_win_mutex_init_and_wait( h, n_win_mutex_literal( n ) )

HANDLE
n_win_mutex_init_and_wait( HANDLE hmutex, const n_win_mutex_char *name )
{

	n_posix_loop
	{
		// [x] : don't use WaitForSingleObject()

		hmutex = n_win_mutex_init( hmutex, name );
		if ( hmutex != NULL ) { break; } else { Sleep( 1 ); }
	}


	return hmutex;
}




#endif // _H_NONNON_WIN32_WIN_MUTEX

