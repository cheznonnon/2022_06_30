// Nonnon COM : Helper Functions
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// Link
//
//	-lole32		COM base system
//	-loleaut32	oleauto.h : BSTR




#ifndef _H_NONNON_WIN32_COM
#define _H_NONNON_WIN32_COM




#include "../neutral/string.c"




#include <ole2.h>
#include <ocidl.h>
#include <servprov.h>


#include <exdisp.h>
#include <mshtml.h>
#include <objidl.h>
#include <shlobj.h>

#ifdef _MSC_VER

#pragma comment( lib, "ole32" )
#pragma comment( lib, "oleaut32" )

#include <docobj.h>
#include <mshtmhst.h>
#include <mshtmcid.h>
#include <mshtmdid.h>

#define HTMLID_FIND        1
#define HTMLID_VIEWSOURCE  2
#define HTMLID_OPTIONS     3

#endif // #ifdef _MSC_VER




#include "./com/guid.c"


#ifndef _MSC_VER

#include "./com/patch.c"

#endif // #ifdef _MSC_VER


//#define N_COM_DEBUG_ONOFF
#include "./com/debug.c"




//#define n_com_init() CoInitialize( NULL )
//#define n_com_exit() CoUninitialize()

#define n_com_init() OleInitialize( NULL )
#define n_com_exit() OleUninitialize()




#define N_COM_GUID_STR_CCH_MAX ( 38 + 1 )

#define n_com_guid_literal( s ) n_com_guid( n_posix_literal( s ) )

GUID
n_com_guid( const n_posix_char *str )
{

	// [Mechanism]
	//
	//	38  = 1 + 8 + 1 + 4 + 1 + 4 + 1 + 4 + 1 + 12 + 1
	//	str = "{00000000-0000-0000-0000-000000000000}";

	if (
		( str == NULL )
		||
		( n_posix_strlen( n_guid_GUID_NULL ) > n_posix_strlen( str ) )
	)
	{
		str = n_guid_GUID_NULL;
	}


	int  offset = 1;

	GUID guid;
	guid.Data1      =       n_string_hex2u32( &str[ offset ], 8 ); offset += 8 + 1;
	guid.Data2      = (u16) n_string_hex2u32( &str[ offset ], 4 ); offset += 4 + 1;
	guid.Data3      = (u16) n_string_hex2u32( &str[ offset ], 4 ); offset += 4 + 1;
	guid.Data4[ 0 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;
	guid.Data4[ 1 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2 + 1;
	guid.Data4[ 2 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;
	guid.Data4[ 3 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;
	guid.Data4[ 4 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;
	guid.Data4[ 5 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;
	guid.Data4[ 6 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;
	guid.Data4[ 7 ] = (u8)  n_string_hex2u32( &str[ offset ], 2 ); offset += 2;

/*
{

	n_posix_char s[ 100 ];

	n_com_debug_guid2str( guid, s );
	n_string_upper( s,s );

	n_posix_debug_literal( "%s\n%s\n%d", str, s, offset );

}
*/


	return guid;
}

void
n_com_class( const n_posix_char *guid_class, const n_posix_char *guid_interface, void **ret )
{

	if ( ret != NULL ) { (*ret) = NULL; }


	// [!] : CLSCTX_ENABLE_CLOAKING
	//
	//	Vista or later : Protected Mode might need this
	//	2000           : handle as invalid error

	//DWORD CLSCTX_ENABLE_CLOAKING = 0x100000;


	GUID c = n_com_guid( guid_class     );
	GUID i = n_com_guid( guid_interface );


	HRESULT hr = CoCreateInstance( &c, NULL, CLSCTX_ALL, &i, ret );

	if ( FAILED( hr ) )
	{
		n_com_debug_a( "n_com_class()" );
	}


	return;
}

void
n_com_interface( void *_this, const n_posix_char *guid_interface, void **ret )
{

	IUnknown *u = _this;


	if ( ret != NULL ) { (*ret) = NULL; }


	if ( u == NULL ) { return; }


	GUID i = n_com_guid( guid_interface );


	HRESULT hr = u->lpVtbl->QueryInterface( u, &i, ret );

	if ( FAILED( hr ) )
	{
		n_com_debug_a( "n_com_interface()" );
	}


	return;
}

void
n_com_release( void *_this )
{

	IUnknown *u = _this;


	if ( u == NULL ) { return; }


	u->lpVtbl->Release( u );


	return;
}

void
n_com_service
(
	void                *_this,
	const n_posix_char  *guid_service,
	const n_posix_char  *guid_interface,
	void               **ret
)
{

	IServiceProvider *sp;


	if ( ret != NULL ) { (*ret) = NULL; }


	n_com_interface( _this, n_guid_IID_IServiceProvider, (void*) &sp );
	if ( sp == NULL )
	{

		n_com_debug_a( "IID_IServiceProvider" );

		return;
	}


	GUID s = n_com_guid( guid_service   );
	GUID i = n_com_guid( guid_interface ); 

	HRESULT hr = IServiceProvider_QueryService( sp, &s, &i, ret );
	if ( FAILED( hr ) )
	{
		n_com_debug_a( "IServiceProvider_QueryService" );
	}


	n_com_release( sp );


	return;
}

#define n_com_override_init( _this, iid, sink, cookie ) n_com_override( _this, iid, sink, cookie, n_posix_true  )
#define n_com_override_exit( _this, iid,       cookie ) n_com_override( _this, iid, NULL, cookie, n_posix_false )

static n_posix_bool n_com_override_enum_onoff = n_posix_false;

void
n_com_override
(
	void               *_this,
	const n_posix_char *iid_target,
	void               *sink,
	DWORD              *cookie,
	n_posix_bool        onoff
)
{

	// [!] : when "cookie" is NULL : cookie-less connection is available


	IConnectionPointContainer *cc;
	IConnectionPoint          *cp;


	n_com_interface( _this, n_guid_IID_IConnectionPointContainer, (void*) &cc );
	if ( cc == NULL )
	{

		n_com_debug_a( "Error : IID_IConnectionPointContainer" );

		return;
	}


	if ( n_com_override_enum_onoff )
	{
#ifdef _H_NONNON_WIN32_COM_DEBUG

		IEnumConnectionPoints *ecp = NULL;
		cc->lpVtbl->EnumConnectionPoints( cc, (void*) &ecp );
		if ( ecp != NULL )
		{

			n_posix_loop
			{

				ULONG count = 0;

				IConnectionPoint *cp = NULL;
				ecp->lpVtbl->Next( ecp, 1, &cp, &count );
				if ( count == 0 ) { break; }

				GUID guid;
				cp->lpVtbl->GetConnectionInterface( cp, (void*) &guid );

				n_posix_char str[ N_COM_GUID_STR_CCH_MAX ];
				n_com_debug_guid2str( guid, str );

				n_posix_debug( str );

				n_com_release( cp );

			}

		}

		n_com_release( ecp );

#endif // #ifdef _H_NONNON_WIN32_COM_DEBUG
	}


	GUID g = n_com_guid( iid_target );

	cc->lpVtbl->FindConnectionPoint( cc, &g, (void*) &cp );
	if ( cp == NULL )
	{

		n_com_debug_a( "Error : IID_IConnectionPoint" );

		return;
	}


	if ( onoff )
	{

		DWORD _cookie = 0;
		if ( cookie == NULL ) { cookie = &_cookie; }

		cp->lpVtbl->Advise( cp, (void*) sink, cookie );

	} else {

		if ( cookie != NULL )
		{

			cp->lpVtbl->Unadvise( cp, *cookie );

		} else {

			IEnumConnections *ec = NULL;
			cp->lpVtbl->EnumConnections( cp, (void*) &ec );

			if ( ec != NULL )
			{

				n_posix_loop
				{

					CONNECTDATA data; ZeroMemory( &data, sizeof( CONNECTDATA ) );
					ULONG       count = 0;
					HRESULT     hr    = ec->lpVtbl->Next( ec, 1, &data, &count );

					if ( hr == S_FALSE ) { break; }

					cp->lpVtbl->Unadvise( cp, data.dwCookie );
					n_com_release( data.pUnk );

//n_posix_debug_literal( "Unadvise()" );
				}

			}// else { n_posix_debug_literal( "x" ); }

			n_com_release( ec );

		}

	}


	n_com_release( cp );
	n_com_release( cc );


	return;
}

#define n_com_bstr_init_literal( s ) n_com_bstr_init( n_posix_literal( s ) )

#define n_com_bstr_exit( bstr ) SysFreeString( bstr )

BSTR
n_com_bstr_init( const n_posix_char *str )
{

	// [!] : you need to do n_com_bstr_exit() with returned BSTR


	if ( str == NULL ) { return NULL; }


#ifdef UNICODE

	wchar_t *wstr = n_string_carboncopy( str );

#else // #ifdef UNICODE

	wchar_t *wstr = n_posix_ansi2unicode( str );

#endif // #ifdef UNICODE


	// [!] : IE4 hasn't SysAllocStringLen();

//n_com_debug_w( wstr );

	BSTR bstr = SysAllocString( wstr );


	n_memory_free( wstr );


	return bstr;
}

n_posix_char*
n_com_bstr2string( BSTR bstr )
{

	// [!] : you need to do n_memory_free() with returned string


#ifdef UNICODE

	n_posix_char *s = n_string_carboncopy( bstr );

#else // #ifdef UNICODE

	n_posix_char *s = n_posix_unicode2ansi( bstr );

#endif // #ifdef UNICODE


	return s;
}

void
n_com_bstr_setwindowtext( HWND hwnd, BSTR bstr )
{

	n_posix_char *s = n_com_bstr2string( bstr );


	SetWindowText( hwnd, s );


	n_memory_free( s );


	return;
}




HRESULT __stdcall
n_com_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
//N_COM_DEBUG_LISTBOX_SET_A( "QueryInterface" );


	// [!] : you need to implement for each interfaces


	if ( ppvObject != NULL ) { (*ppvObject) = NULL; }


	GUID g = n_com_guid( n_guid_IID_IUnknown );

	if ( IsEqualGUID( iid, &g ) )
	{

//n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );

		if ( ppvObject != NULL ) { (*ppvObject) = _this; }

		return S_OK;
	}


	return E_NOINTERFACE;
}

ULONG __stdcall
n_com_IUnknown_AddRef( void *_this )
{
//N_COM_DEBUG_LISTBOX_SET_A( "AddRef" );

	return S_OK;
}

ULONG __stdcall
n_com_IUnknown_Release( void *_this )
{
//N_COM_DEBUG_LISTBOX_SET_A( "Release" );

	return S_OK;
}




HRESULT __stdcall
n_com_IDispatch_GetTypeInfoCount( void *_this, unsigned int *pctinfo )
{
N_COM_DEBUG_LISTBOX_SET_A( "GetTypeInfoCount" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_com_IDispatch_GetTypeInfo( void *_this, unsigned int iTInfo, LCID lcid, ITypeInfo **i )
{
N_COM_DEBUG_LISTBOX_SET_A( "GetTypeInfo" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_com_IDispatch_GetIDsOfNames
(
	void          *_this,
	REFIID         riid,
	OLECHAR      **rgszNames,
	unsigned int   cNames,
	LCID           lcid,
	DISPID        *rgDispId
)
{
N_COM_DEBUG_LISTBOX_SET_A( "GetIDsOfNames" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_com_IDispatch_Invoke
(
	void         *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{
N_COM_DEBUG_LISTBOX_SET_A( "Invoke" );


	// [!] : you need to implement for each interfaces


/*
	n_com_debug_IDispatch_Invoke
	(
		_this,
		dispIdMember,
		riid,
		lcid,
		wFlags,
		pDispParams,
		pVarResult,
		pExcepInfo,
		puArgErr
	);
*/


	switch( dispIdMember ) {

	default :

		return DISP_E_MEMBERNOTFOUND;

	break;


	} // switch


	return S_OK;
}


#endif // _H_NONNON_WIN32_COM

